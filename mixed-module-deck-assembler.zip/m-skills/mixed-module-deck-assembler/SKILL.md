---
name: "mixed-module-deck-assembler"
description: "Assemble a custom mixed-module PowerPoint deck from a module-library manifest using a prompt, customer notes, win-room context, desired audience, and selected module IDs."
---

# Mixed Module Deck Assembler Skill

Use this skill when the user wants to assemble or propose a custom PowerPoint deck from an existing PPTX module library created by `/pptx-module-library`.

## Required companion skills

Because PowerPoint files are involved, always load and follow `/pptx` first. If the library needs to be imported, refreshed, title-slide styles are missing, or the assembly runtime is outdated, load and use `/pptx-module-library` first.

## Main library root discovery

Do not hardcode URLs or tenant-specific locations. When the user has not supplied a manifest or library root:

1. Search memory for the user's chosen `pptx-module-library` or MTT module library root.
2. Confirm the remembered root before using it.
3. If no remembered root exists, ask the user to choose one and suggest `MTT Module Library` in their OneDrive root. Resolve the OneDrive root dynamically from the local machine.
4. Remember the confirmed root for future assembly runs.

Recommended folder name: `MTT Module Library`.

## Mandatory title prompt

Before assembling any deck, explicitly prompt the user for the deck title unless they already provided one in the request or explicitly said to create no title slide. Do not invent a title silently. If the user says to skip the title slide, pass no `--title` argument and record that decision in the assembly manifest.

If the user provides only context, notes, module IDs, or an output path, stop and ask for the deck title before running `assemble_deck.py`.

## Mandatory max-slide prompt

Before assembling, prompt for the maximum slides per deck unless the user already provided a number. Recommend `50`, but allow any practical positive integer such as `51`, `75`, or a larger one-day delivery deck. Count the generated title slide as one slide. Pass the confirmed value to `assemble_deck.py --max-slides`.

## Deck limit and naming

Pack whole modules into each deck without splitting inside a module unless the user explicitly asks for slide-level splitting.

If the selected modules exceed the confirmed max-slide count, create multiple decks automatically. Always use numbered output filenames, even when only one file is produced:

```text
Custom-Name-01.pptx
Custom-Name-02.pptx
Custom-Name-03.pptx
```

Use the user-provided output stem or a filesystem-safe version of the custom title as `Custom-Name`. Keep the same deck title on every numbered part unless the user requests part-specific titles. If a single module is larger than the max-slide limit, place it in its own numbered deck and record the exception in the assembly manifest.

## Inputs to collect

Prompt for any missing required input:

1. Path to `module-library.manifest.json`, or the main library root containing it.
2. Custom deck title, unless the user explicitly says no title slide.
3. Maximum slides per deck. Recommend `50` but use the user's chosen value.
4. Optional subtitle.
5. Preferred title-slide style course/import, if the library has multiple `title_slide_styles`; otherwise default to the first selected module's course.
6. User goal or context: win-room prompt, customer-call notes, customer scenario, product area, desired outcome, or explicit module list.
7. Desired output folder or output base `.pptx` path. The generated files must still be numbered `-01`, `-02`, etc.
8. Audience and depth if not obvious.
9. Whether to include each module's first/title slide. Default: include title slides unless the user asks for a streamlined deck.

## Module selection workflow

1. Read `module-library.manifest.json` from the main library root.
2. Use `search_metadata`, module titles, descriptions, keywords, course IDs, slide counts, and scenario fit to rank relevant modules.
3. If the user gave explicit module IDs, preserve that order unless they ask for optimization.
4. If the user gave notes or a prompt, propose a short ordered module list with module ID, title, course, slide count, reason selected, cumulative slide count, and expected deck part number using the confirmed max-slide count.
5. Ask for confirmation before assembling if the user did not provide an explicit ordered module list.
6. Avoid mixing redundant modules unless the user asks for a comprehensive deck.

## Title-slide behavior

Use the `title_slide_styles` array in the top-level manifest. When assembling with a custom title:

1. Prefer the style for `--title-style-course` if supplied.
2. Otherwise use the first selected module's course style.
3. Otherwise use the first available indexed style.
4. Clone the indexed title slide and replace the title text, preserving the original slide design.
5. Use `--subtitle` when the user provides a subtitle.

## Assembly behavior

Use the existing library runtime whenever available:

```powershell
python assemble_deck.py --library module-library.manifest.json --modules AZ-400-LP01-M01,AZ-204-LP01-M01 --title "Customer DevOps Briefing" --subtitle "Selected learning modules" --title-style-course AZ-400 --max-slides 50 --out Customer-DevOps-Briefing.pptx
```

The runtime should output `Customer-DevOps-Briefing-01.pptx`, and if needed `Customer-DevOps-Briefing-02.pptx`, etc. Run from, or point to, the main library root. The generated `assemble_deck.py` should use PowerPoint COM `Slides.InsertFromFile` with contiguous slide ranges and save through a local temp `.pptx` before copying to OneDrive-backed destinations.

If `pywin32` is missing, install it with:

```powershell
python -m pip install pywin32
```

## Output expectations

Create one or more numbered `.pptx` files, a per-part `<deck-name>-NN.assembly.json`, and an aggregate `<deck-name>.assembly.json` listing all numbered deck parts. Each manifest should include source module-library manifest, selected modules in order, prompt/context summary when available, custom title/subtitle, selected title-slide style, include-title-slide setting, max slide limit, part number, total parts, estimated slide count, and output path.

## Validation

After assembly, confirm every numbered output `.pptx` exists and is non-empty, every selected module ID exists in the library manifest, each deck part is at or below the confirmed max-slide limit unless a single-module exception is recorded, and slide 1 contains the custom title when a title slide is requested.

## Safety and privacy

Do not send private customer notes, win-room context, or deck content to third-party services. Keep generated files in the user-specified local/OneDrive location. If the assembled deck contains private customer context, warn before sharing externally.
