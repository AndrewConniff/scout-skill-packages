## mixed-module-deck-assembler dependencies

### Included in this bundle

- `m-skills/mixed-module-deck-assembler/SKILL.md`

### Required runtime inputs (produced by pptx-module-library)

- `module-library.manifest.json`
- `assemble_deck.py`
- `courses_runtime.py`
- course/module manifests referenced by `module-library.manifest.json`

### External runtime dependencies

- Companion Scout skills:
  - `/pptx` (bundled in Scout)
  - `/pptx-module-library` (this custom pair dependency)
- Python 3
- `pywin32` for `assemble_deck.py` PowerPoint COM execution

