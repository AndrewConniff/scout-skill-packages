---
name: "pptx-module-library"
description: "Split course PowerPoint decks into reusable module folders with Python reconstruction scripts, extracted assets, per-course manifests, and a top-level manifest for prompt-driven deck assembly."
---

# PPTX Module Library Skill

Use this skill when the user wants to turn one or more folders of PowerPoint course decks into a reusable module library for later deck assembly or reassembly by Scout, Cowork, GitHub Copilot, or other agents.

## Required companion skill

Because PowerPoint files are involved, always load and follow `/pptx` first.

## Core model

The first user-provided folder is the persistent main module-library root. It holds the global manifest, index, title-slide style index, and assembly runtime. Each imported PPTX source folder becomes a same-named child folder under that root.

The business goal is for an MTT to index the classes they deliver, then rapidly curate customer-ready decks from those indexed modules.

## Main library root discovery

Do not hardcode URLs or tenant-specific locations in the skill. When the user has not supplied a main library root:

1. Search memory for a previously chosen `pptx-module-library` or MTT module library root.
2. If a remembered root exists, confirm it before using it.
3. If no remembered root exists, recommend a folder named `MTT Module Library` in the user's OneDrive root. Resolve the OneDrive root dynamically from the local machine, preferring `OneDrive - Microsoft` when present and falling back to `OneDrive`.
4. Let the user accept the recommended folder or choose another folder.
5. After the user confirms the library root, create the folder if needed and remember the chosen path for future runs.

Recommended folder name: `MTT Module Library`.

## Required prompts

Before processing anything, prompt for every missing input: main module-library root folder, source PPTX folder to import, course naming rule if needed, and module boundary rule if sections or reliable courseware patterns are not detectable. Confirm the resolved main root and same-named import child folder before writing.

## Suggested next imports

After completing an import, proactively look for other PPTX source folders in the same general location so the user can keep building the library efficiently. Search nearby folders for `.pptx` sets, exclude the just-imported and already-indexed folders, prefer readable folders with multiple PPTX files, and present 2-5 candidates plus a `Different path` option.

## Output layout

Create or update this structure:

```text
main-library-root/
  module-library.manifest.json
  module-library.index.md
  assemble_deck.py
  courses_runtime.py
  <source-folder-name>/
    courses/
      <course-id>/
        course.manifest.json
        source/
          original-file-name.pptx
        modules/
          lp01-001-section-title-slug/
            module.py
            module.manifest.json
            images/
            media/
            theme/
            slides/
        shared/
          pptx_module_runtime.py
          assets/
```

## Import/update/reindex behavior

- Process one source PPTX folder at a time.
- Copy source `.pptx` files into the course `source/` folder; never modify originals.
- Reindexing is supported: if a class/course already exists in the global manifest, importing a newer source folder for the same `course_id` replaces the prior indexed version.
- Replacement is by `course_id` and by `import_folder`. Preserve unrelated courses/modules.
- When replacing an older version whose import folder name differs, remove only that older generated import child folder under the main library root. Never delete source decks or folders outside the main library root.
- Record replaced import folders in `replaces_import_folders` on the new course entry.
- Use the current source folder name as `import_folder` in the global manifest.
- If OneDrive files are online-only placeholders and unreadable, start OneDrive if appropriate. If support decks remain unavailable, skip them and record them in `unavailable_source_decks`. If a module-bearing deck is unavailable, stop and report the exact file.

## Module detection

Prefer native PowerPoint Sections if present. Preserve section titles and exclude the overall deck title/cover slide from module output unless the user asks to keep it.

If no native PowerPoint Sections exist, infer module boundaries from divider slides such as `Module 01: Title`, use agenda entries to recover full module titles when text wraps, treat numbered courseware decks as learning paths, include module divider slides in their module, and track pre-module/support slides in `slides_excluded`. Opening, introduction, conclusion, and closing decks without module boundaries should be copied and indexed as support decks, not converted into giant catch-all modules.

## Title-slide style indexing

While indexing, preserve title-slide style metadata so assembled decks can start with a custom title while keeping original courseware design. Record `title_slide_candidates` per course and a global `title_slide_styles` array in `module-library.manifest.json`. Prefer slide 1 of the first numbered learning-path deck as the course's `default_title_slide_style`.

## Assembly runtime requirements

Generate `assemble_deck.py` and `courses_runtime.py` at the main library root. The runtime must:

1. Use PowerPoint COM on Windows through `pywin32`.
2. Use `Slides.InsertFromFile(source, index, first_slide, last_slide)` with contiguous slide ranges, not clipboard copy/paste.
3. Support `--title`, `--subtitle`, `--title-style-course`, and `--max-slides`.
4. Default `--max-slides` to 50, but the assembler skill should prompt users for their desired max because delivery scenarios vary.
5. When selected modules exceed the max slide count, split whole modules across multiple output decks.
6. Always number outputs with a two-digit suffix, even for a single deck: `Custom-Name-01.pptx`, `Custom-Name-02.pptx`.
7. Clone the indexed title slide style into each numbered part when `--title` is supplied, replacing only the title/subtitle text where possible.
8. Save to a local temporary `.pptx` first, then copy into the requested destination to avoid OneDrive-backed SaveAs failures.
9. Write per-part assembly manifests and an aggregate assembly manifest.

Example:

```powershell
python assemble_deck.py --library module-library.manifest.json --modules AZ-400-LP01-M01,AZ-204-LP01-M01 --title "Customer DevOps Briefing" --subtitle "Selected modules" --title-style-course AZ-400 --max-slides 50 --out Customer-DevOps-Briefing.pptx
```

Expected output starts with `Customer-DevOps-Briefing-01.pptx`; additional parts are `-02`, `-03`, etc.

## Manifests

Each course manifest must include course/source metadata, source decks, unavailable source decks, title-slide candidates, default title-slide style, excluded slides, and modules. Each module manifest must include module ID, course ID, learning path, title, source slide numbers, slide count, description, keywords, audience/level/scenario metadata, assets, Python entrypoint, and assembly notes. The top-level manifest must include imported folders, courses, modules, title-slide styles, and prompt-search metadata.

Also create `module-library.index.md` as a human-readable table with imported folder, course ID, module ID, title, slide count, description, keywords, and folder path.

## Reference implementation

Use the helper script stored with this skill:

```powershell
python <skill-folder>\scripts\pptx_module_library_builder.py --source "<source-pptx-folder>" --output "<main-library-root>"
```

`--output` means the main library root, not the per-course child folder. The script creates the same-named import child folder automatically.

## Fidelity strategy

Preserve design and style. Prefer lossless or near-lossless slide reuse over manual recreation. Title slides should be cloned from indexed title-slide candidates rather than rebuilt from scratch.

## Validation

After processing, verify the import child folder exists, module folders/manifests/scripts exist, the global manifest references imported folders/courses/modules/title-slide styles correctly, generated Python files compile, and a sample assembled deck works. For multi-course libraries, assemble at least one mixed sample deck with a custom title and confirm numbered outputs stay within the requested max-slide limit unless a single-module exception is recorded.

## Important constraints

- Do not send private deck content to third-party services.
- For SharePoint or OneDrive-hosted presentations, follow `/pptx` SharePoint guidance first.
- Do not overwrite source decks.
- Never delete source decks; only remove older generated import folders inside the confirmed main library root during reindex replacement.
- Keep filenames filesystem-safe and cap generated slug length to avoid Windows path errors.
- Include learning path or deck identifiers in module folder names to avoid collisions across decks.
- Record fidelity limitations in manifests instead of hiding them.
