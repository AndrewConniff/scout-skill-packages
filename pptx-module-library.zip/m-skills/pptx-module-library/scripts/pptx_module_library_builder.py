from __future__ import annotations

import argparse
import json
import re
import shutil
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET


NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
}
REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
OD_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"


def slugify(value: str, fallback: str, max_length: int = 80) -> str:
    value = value.strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    value = re.sub(r"-+", "-", value).strip("-")
    value = value or fallback
    if len(value) <= max_length:
        return value
    return value[:max_length].rstrip("-") or fallback


def norm_text(parts: list[str]) -> str:
    return re.sub(r"\s+", " ", " ".join(parts)).strip()


def read_xml(zf: zipfile.ZipFile, name: str) -> ET.Element:
    return ET.fromstring(zf.read(name))


def rels_path(part_name: str) -> str:
    path = Path(part_name)
    return str(path.parent / "_rels" / f"{path.name}.rels").replace("\\", "/")


def slide_order(zf: zipfile.ZipFile) -> list[str]:
    pres = read_xml(zf, "ppt/presentation.xml")
    rels = read_xml(zf, "ppt/_rels/presentation.xml.rels")
    rid_to_target = {rel.attrib["Id"]: rel.attrib["Target"] for rel in rels}
    slides = []
    for slide_id in pres.find("p:sldIdLst", NS) or []:
        rid = slide_id.attrib[OD_REL]
        target = rid_to_target[rid].lstrip("/")
        slides.append(("ppt/" + target).replace("\\", "/"))
    return slides


def slide_text(zf: zipfile.ZipFile, slide_name: str) -> list[str]:
    root = read_xml(zf, slide_name)
    return [node.text.strip() for node in root.findall(".//a:t", NS) if node.text and node.text.strip()]


def first_title(parts: list[str]) -> str:
    for part in parts:
        cleaned = part.strip()
        if cleaned and cleaned.lower() not in {"agenda", "demo", "de", "mo"}:
            return cleaned
    return ""


def extract_course_id(source: Path, pptx_files: list[Path]) -> str:
    candidates = [source.name, *[p.name for p in pptx_files], *[p.name for p in source.parents]]
    for item in candidates:
        match = re.search(r"\b([A-Z]{2,4}-\d{3,4}[A-Z]?)\b", item, re.I)
        if match:
            return match.group(1).upper()
    return slugify(source.name, "course").upper()


def extract_learning_path_id(pptx: Path) -> str:
    match = re.search(r"_(\d{2})(?:\D|$)", pptx.stem)
    if match:
        return f"LP{match.group(1)}"
    if "introduction" in pptx.stem.lower():
        return "INTRO"
    if "conclusion" in pptx.stem.lower():
        return "CONCLUSION"
    return slugify(pptx.stem, "deck").upper()


def is_support_deck(pptx: Path) -> bool:
    return any(token in pptx.stem.lower() for token in ["introduction", "intro", "opening", "closing", "conclusion"])


def can_read_file(path: Path) -> tuple[bool, str | None]:
    try:
        with path.open("rb") as handle:
            handle.read(4)
        return True, None
    except OSError as exc:
        return False, str(exc)


def agenda_titles(all_text: dict[int, list[str]]) -> dict[str, str]:
    titles: dict[str, str] = {}
    for slide_num in sorted(all_text)[:4]:
        text = norm_text(all_text[slide_num])
        if "agenda" not in text.lower() and "module" not in text.lower():
            continue
        for match in re.finditer(
            r"Module\s*(\d{1,2})\s*:\s*(.*?)(?=\s+Module\s*\d{1,2}\s*:|\s+Labs\b|\s+Learning Path review\b|$)",
            text,
            flags=re.I,
        ):
            number = f"{int(match.group(1)):02d}"
            title = match.group(2).strip(" .|")
            if title:
                titles[number] = title
    return titles


def module_marker(text: str) -> tuple[str, str] | None:
    match = re.search(r"\bModule\s*(\d{1,2})\s*:\s*(.+)$", text, flags=re.I)
    if not match:
        return None
    title = match.group(2).strip(" .|")
    return f"{int(match.group(1)):02d}", title


def detect_modules(zf: zipfile.ZipFile, pptx: Path, slides: list[str]) -> tuple[list[dict], dict[int, list[str]], list[dict]]:
    all_text = {idx: slide_text(zf, slide) for idx, slide in enumerate(slides, 1)}
    agenda = agenda_titles(all_text)
    starts: list[tuple[int, str, str]] = []
    for idx in range(3, len(slides) + 1):
        text = norm_text(all_text[idx])
        marker = module_marker(text)
        if marker:
            number, detected_title = marker
            starts.append((idx, number, agenda.get(number, detected_title)))

    seen = set()
    unique_starts: list[tuple[int, str, str]] = []
    for start in starts:
        key = (start[0], start[1])
        if key not in seen:
            unique_starts.append(start)
            seen.add(key)

    modules: list[dict] = []
    excluded: list[dict] = [{"slide": 1, "reason": "deck title or cover slide"}] if slides else []
    if not unique_starts:
        if is_support_deck(pptx):
            return [], all_text, [
                {"slide": idx, "reason": "support deck without detected module boundaries"}
                for idx in range(1, len(slides) + 1)
            ]
        title = first_title(all_text.get(1, [])) or pptx.stem
        module_slides = list(range(2, len(slides) + 1)) if len(slides) > 1 else []
        if module_slides:
            modules.append({"number": "01", "title": title, "slides": module_slides, "kind": "deck"})
        return modules, all_text, excluded

    first_start = unique_starts[0][0]
    for slide_num in range(2, first_start):
        excluded.append({"slide": slide_num, "reason": "pre-module agenda or learning path overview"})

    for pos, (start, number, title) in enumerate(unique_starts):
        end = unique_starts[pos + 1][0] - 1 if pos + 1 < len(unique_starts) else len(slides)
        modules.append({"number": number, "title": title, "slides": list(range(start, end + 1)), "kind": "module"})

    last_module = modules[-1]
    labs_start = None
    for slide_num in last_module["slides"]:
        text = norm_text(all_text[slide_num]).lower()
        if text in {"labs", "learning path review and takeaways"} or text.startswith("labs "):
            labs_start = slide_num
            break
    if labs_start and labs_start > last_module["slides"][0]:
        last_module["slides"] = [n for n in last_module["slides"] if n < labs_start]
        labs_slides = list(range(labs_start, len(slides) + 1))
        modules.append({"number": "LABS", "title": "Labs and Learning Path Review", "slides": labs_slides, "kind": "labs-review"})

    return [m for m in modules if m["slides"]], all_text, excluded


def keywords_from_text(text: str) -> list[str]:
    product_terms = [
        "Azure",
        "Azure DevOps",
        "Azure Boards",
        "Azure Repos",
        "Azure Pipelines",
        "GitHub",
        "GitHub Actions",
        "GitHub Packages",
        "Bicep",
        "ARM",
        "Docker",
        "Kubernetes",
        "DevOps",
        "YAML",
        "CI",
        "CD",
        "Security",
        "Compliance",
        "Monitoring",
    ]
    found = []
    lower = text.lower()
    for term in product_terms:
        if term.lower() in lower:
            found.append(term)
    words = re.findall(r"\b[A-Za-z][A-Za-z0-9+#.-]{3,}\b", text)
    stop = {"module", "learn", "learning", "path", "overview", "slide", "microsoft", "rights", "reserved", "copyright"}
    counts = Counter(w.strip(".,:;()").lower() for w in words if w.lower() not in stop)
    for word, _ in counts.most_common(12):
        label = word.upper() if word in {"ci", "cd", "yaml", "dsc"} else word.title()
        if label not in found:
            found.append(label)
    return found[:15]


def description_for(title: str, slide_texts: list[str]) -> str:
    text = " ".join(slide_texts)
    objectives = []
    for marker in ["Objectives:", "In this module", "In this lab", "What did you learn?"]:
        idx = text.lower().find(marker.lower())
        if idx >= 0:
            snippet = re.sub(r"\s+", " ", text[idx : idx + 500]).strip()
            if snippet:
                objectives.append(snippet)
    if objectives:
        return f"Covers {title}. {objectives[0][:360].rstrip()}".strip()
    keywords = ", ".join(keywords_from_text(text)[:6])
    return f"Covers {title}" + (f", including {keywords}." if keywords else ".")


def copy_assets_for_module(zf: zipfile.ZipFile, slide_names: list[str], module_dir: Path) -> list[dict]:
    assets: list[dict] = []
    copied = set()
    for slide_name in slide_names:
        rel_name = rels_path(slide_name)
        if rel_name not in zf.namelist():
            continue
        rel_root = read_xml(zf, rel_name)
        base = Path(slide_name).parent
        for rel in rel_root:
            target = rel.attrib.get("Target", "")
            rel_type = rel.attrib.get("Type", "")
            if target.startswith("http"):
                continue
            package_target = str((base / target).as_posix())
            package_target = re.sub(r"[^/]+/\.\./", "", package_target)
            if package_target not in zf.namelist() or package_target in copied:
                continue
            copied.add(package_target)
            ext = Path(package_target).suffix.lower()
            if "/media/" in package_target and ext in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".svg", ".emf", ".wmf"}:
                dest_dir = module_dir / "images"
            elif "/media/" in package_target:
                dest_dir = module_dir / "media"
            else:
                dest_dir = module_dir / "theme"
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / Path(package_target).name
            with zf.open(package_target) as src, dest.open("wb") as out:
                shutil.copyfileobj(src, out)
            assets.append({"source": package_target, "path": str(dest.relative_to(module_dir)).replace("\\", "/"), "relationship_type": rel_type})
    return assets


def copy_slide_fragments(zf: zipfile.ZipFile, slide_names: list[str], module_dir: Path) -> None:
    slides_dir = module_dir / "slides"
    slides_dir.mkdir(parents=True, exist_ok=True)
    for slide_name in slide_names:
        for package_name in [slide_name, rels_path(slide_name)]:
            if package_name in zf.namelist():
                dest = slides_dir / package_name.replace("/", "__")
                with zf.open(package_name) as src, dest.open("wb") as out:
                    shutil.copyfileobj(src, out)


RUNTIME = r'''from __future__ import annotations

import json
import shutil
import tempfile
from pathlib import Path


class PowerPointModuleBuilder:
    def __init__(self, output_path):
        self.output_path = str(Path(output_path).resolve())
        try:
            import win32com.client
        except ImportError as exc:
            raise RuntimeError("PowerPoint assembly requires pywin32: python -m pip install pywin32") from exc
        self._ppt = win32com.client.Dispatch("PowerPoint.Application")
        self._ppt.Visible = True
        self._dest = self._ppt.Presentations.Add()

    def _slide_ranges(self, slide_numbers):
        if not slide_numbers:
            return
        start = previous = int(slide_numbers[0])
        for slide_number in [int(value) for value in slide_numbers[1:]]:
            if slide_number == previous + 1:
                previous = slide_number
                continue
            yield start, previous
            start = previous = slide_number
        yield start, previous

    def add_title_slide(self, title, *, subtitle=None, style=None):
        if not style:
            return self
        source = Path(style["source_pptx"])
        slide_number = int(style.get("slide_number", 1))
        self._dest.Slides.InsertFromFile(str(source), self._dest.Slides.Count, slide_number, slide_number)
        slide = self._dest.Slides(self._dest.Slides.Count)
        text_shapes = []
        for index in range(1, slide.Shapes.Count + 1):
            shape = slide.Shapes(index)
            try:
                if shape.HasTextFrame and shape.TextFrame.HasText:
                    text = shape.TextFrame.TextRange.Text.strip()
                    if text:
                        text_shapes.append((len(text), shape))
            except Exception:
                continue
        try:
            slide.Shapes.Title.TextFrame.TextRange.Text = title
        except Exception:
            if text_shapes:
                text_shapes[0][1].TextFrame.TextRange.Text = title
        if subtitle and len(text_shapes) > 1:
            text_shapes = sorted(text_shapes, key=lambda item: item[0], reverse=True)
            text_shapes[1][1].TextFrame.TextRange.Text = subtitle
        return self

    def append_module(self, module_file, *, include_title=True):
        module_dir = Path(module_file).resolve().parent
        manifest = json.loads((module_dir / "module.manifest.json").read_text(encoding="utf-8"))
        source = Path(manifest["source_pptx"])
        if not source.is_absolute():
            source = (module_dir / source).resolve()
        slide_numbers = list(manifest["source_slide_numbers"])
        if not include_title and slide_numbers:
            slide_numbers = slide_numbers[1:]
        for first_slide, last_slide in self._slide_ranges(slide_numbers):
            self._dest.Slides.InsertFromFile(str(source), self._dest.Slides.Count, first_slide, last_slide)
        return self

    def save(self):
        output = Path(self.output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        temp_output = Path(tempfile.gettempdir()) / output.name
        if temp_output.exists():
            temp_output.unlink()
        self._dest.SaveAs(str(temp_output), 24)
        self._dest.Close()
        shutil.copy2(temp_output, output)
        temp_output.unlink()
        return self.output_path
'''


ASSEMBLER = r'''from __future__ import annotations

import argparse
import importlib.util
import json
import re
from pathlib import Path

from courses_runtime import PowerPointModuleBuilder


def slugify(value, fallback="custom-deck"):
    value = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-")
    return value or fallback


def numbered_output(base_output, title, part_number):
    path = Path(base_output).resolve()
    if path.suffix.lower() == ".pptx":
        parent = path.parent
        stem = path.stem
    else:
        parent = path
        stem = slugify(title or "custom-deck")
    return parent / f"{stem}-{part_number:02d}.pptx"


def module_slide_count(entry, include_module_title):
    count = int(entry.get("slide_count", 0))
    if not include_module_title and entry.get("source_slide_numbers"):
        count = max(0, count - 1)
    return count


def split_modules(selected_entries, *, max_slides, include_title_slide, include_module_title):
    title_cost = 1 if include_title_slide else 0
    chunks = []
    current = []
    current_count = title_cost
    for entry in selected_entries:
        module_count = module_slide_count(entry, include_module_title)
        if current and current_count + module_count > max_slides:
            chunks.append(current)
            current = []
            current_count = title_cost
        current.append(entry)
        current_count += module_count
    if current:
        chunks.append(current)
    return chunks


def load_module(path: Path):
    spec = importlib.util.spec_from_file_location(path.parent.name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module script: {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main():
    parser = argparse.ArgumentParser(description="Assemble a PowerPoint deck from module-library manifests.")
    parser.add_argument("--library", required=True, help="Path to module-library.manifest.json")
    parser.add_argument("--modules", required=True, help="Comma-separated module IDs")
    parser.add_argument("--out", required=True, help="Output .pptx path")
    parser.add_argument("--title", help="Custom title for a generated title slide")
    parser.add_argument("--subtitle", help="Optional subtitle for the generated title slide")
    parser.add_argument("--title-style-course", help="Course ID whose indexed title-slide style should be used")
    parser.add_argument("--max-slides", type=int, default=50, help="Maximum slides per output deck; defaults to 50")
    parser.add_argument("--no-module-title", action="store_true", help="Skip each module's first/title slide")
    args = parser.parse_args()

    library_path = Path(args.library).resolve()
    library = json.loads(library_path.read_text(encoding="utf-8"))
    by_id = {m["module_id"]: m for m in library["modules"]}
    selected_module_ids = [m.strip() for m in args.modules.split(",") if m.strip()]
    selected_entries = [by_id[module_id] for module_id in selected_module_ids]
    include_module_title = not args.no_module_title
    chunks = split_modules(
        selected_entries,
        max_slides=args.max_slides,
        include_title_slide=bool(args.title),
        include_module_title=include_module_title,
    )
    outputs = []
    for part_number, chunk_entries in enumerate(chunks, 1):
        part_output = numbered_output(args.out, args.title, part_number)
        builder = PowerPointModuleBuilder(part_output)
        style = None
        if args.title_style_course:
            for candidate in library.get("title_slide_styles", []):
                if candidate.get("course_id") == args.title_style_course:
                    style = candidate
                    break
        if style is None and chunk_entries:
            first_course = chunk_entries[0].get("course_id")
            for candidate in library.get("title_slide_styles", []):
                if candidate.get("course_id") == first_course:
                    style = candidate
                    break
        if style is None and library.get("title_slide_styles"):
            style = library["title_slide_styles"][0]
        if args.title:
            builder.add_title_slide(args.title, subtitle=args.subtitle, style=style)
        for entry in chunk_entries:
            module_path = (library_path.parent / entry["python_entrypoint"]).resolve()
            module = load_module(module_path)
            module.append_to_deck(builder, include_title=include_module_title)
        saved = builder.save()
        estimated_slide_count = (1 if args.title else 0) + sum(module_slide_count(entry, include_module_title) for entry in chunk_entries)
        assembly = {
            "source_module_library": str(library_path),
            "output_path": str(part_output),
            "part_number": part_number,
            "total_parts": len(chunks),
            "max_slides": args.max_slides,
            "estimated_slide_count": estimated_slide_count,
            "title": args.title,
            "subtitle": args.subtitle,
            "title_style_course": args.title_style_course,
            "include_module_title_slides": include_module_title,
            "selected_modules": chunk_entries,
        }
        part_output.with_suffix(".assembly.json").write_text(json.dumps(assembly, indent=2), encoding="utf-8")
        outputs.append(str(saved))
    aggregate = {
        "source_module_library": str(library_path),
        "base_output": str(Path(args.out).resolve()),
        "title": args.title,
        "subtitle": args.subtitle,
        "max_slides": args.max_slides,
        "total_parts": len(outputs),
        "outputs": outputs,
        "selected_module_ids": selected_module_ids,
    }
    base = Path(args.out).resolve()
    aggregate_path = (base.with_suffix("") if base.suffix.lower() == ".pptx" else base / slugify(args.title or "custom-deck")).with_suffix(".assembly.json")
    aggregate_path.write_text(json.dumps(aggregate, indent=2), encoding="utf-8")
    for saved in outputs:
        print(saved)


if __name__ == "__main__":
    main()
'''


def module_py(module_id: str, module_title: str) -> str:
    return f'''from __future__ import annotations

MODULE_ID = {module_id!r}
MODULE_TITLE = {module_title!r}


def append_to_deck(builder, *, include_title=True):
    """Append this module's slides to the target deck builder."""
    return builder.append_module(__file__, include_title=include_title)


def manifest_path():
    from pathlib import Path
    return Path(__file__).with_name("module.manifest.json")
'''


def title_slide_candidate(source_copy: Path, pptx: Path, lp_id: str, slide_count: int, text: list[str]) -> dict:
    return {
        "source_pptx": str(source_copy.resolve()),
        "source_file_name": pptx.name,
        "slide_number": 1,
        "learning_path": lp_id,
        "title_text": norm_text(text)[:300],
        "slide_count": slide_count,
    }


def build(source: Path, library_root: Path) -> None:
    source = source.resolve()
    library_root = library_root.resolve()
    output = library_root / source.name
    pptx_files = sorted(source.glob("*.pptx"))
    if not pptx_files:
        raise RuntimeError(f"No .pptx files found in {source}")
    course_id = extract_course_id(source, pptx_files)
    generated_at = datetime.now(timezone.utc).isoformat()
    course_dir = output / "courses" / course_id
    modules_root = course_dir / "modules"
    source_dir = course_dir / "source"
    shared_dir = course_dir / "shared"
    for directory in [modules_root, source_dir, shared_dir]:
        directory.mkdir(parents=True, exist_ok=True)
    (shared_dir / "pptx_module_runtime.py").write_text(RUNTIME, encoding="utf-8")
    (library_root / "courses_runtime.py").write_text(RUNTIME, encoding="utf-8")
    (library_root / "assemble_deck.py").write_text(ASSEMBLER, encoding="utf-8")

    library_modules = []
    course_modules = []
    slides_excluded = []
    source_entries = []
    unavailable_source_decks = []
    title_slide_candidates = []

    for pptx in pptx_files:
        readable, error = can_read_file(pptx)
        if not readable and is_support_deck(pptx):
            unavailable_source_decks.append(
                {
                    "file": pptx.name,
                    "path": str(pptx),
                    "reason": f"Skipped unavailable support deck: {error}",
                }
            )
            continue
        if not readable:
            raise RuntimeError(f"Cannot read module source deck {pptx}: {error}")
        source_copy = source_dir / pptx.name
        if not source_copy.exists() or source_copy.stat().st_size != pptx.stat().st_size:
            shutil.copy2(pptx, source_copy)
        lp_id = extract_learning_path_id(pptx)
        with zipfile.ZipFile(pptx) as zf:
            slides = slide_order(zf)
            all_text = {idx: slide_text(zf, slide) for idx, slide in enumerate(slides, 1)}
            title_candidate = title_slide_candidate(source_copy, pptx, lp_id, len(slides), all_text.get(1, []))
            title_slide_candidates.append(title_candidate)
            source_entries.append({
                "file": str(source_copy.relative_to(course_dir)).replace("\\", "/"),
                "slide_count": len(slides),
                "learning_path": lp_id,
                "title_slide_candidate": title_candidate,
            })
            if is_support_deck(pptx):
                for slide_num in range(1, len(slides) + 1):
                    slides_excluded.append(
                        {
                            "slide": slide_num,
                            "reason": "support deck indexed for title/style metadata, not module output",
                            "source_pptx": pptx.name,
                            "learning_path": lp_id,
                        }
                    )
                continue
            modules, all_text, excluded = detect_modules(zf, pptx, slides)
            for item in excluded:
                item = dict(item)
                item["source_pptx"] = pptx.name
                item["learning_path"] = lp_id
                slides_excluded.append(item)
            for ordinal, module in enumerate(modules, 1):
                if module["number"] == "LABS":
                    module_id = f"{course_id}-{lp_id}-LABS"
                    folder_name = f"{lp_id.lower()}-{ordinal:03d}-labs-and-learning-path-review"
                else:
                    module_id = f"{course_id}-{lp_id}-M{module['number']}"
                    folder_name = f"{lp_id.lower()}-{ordinal:03d}-{slugify(module['title'], 'module')}"
                module_dir = modules_root / folder_name
                for sub in ["images", "media", "theme", "slides"]:
                    (module_dir / sub).mkdir(parents=True, exist_ok=True)
                slide_names = [slides[n - 1] for n in module["slides"]]
                copy_slide_fragments(zf, slide_names, module_dir)
                assets = copy_assets_for_module(zf, slide_names, module_dir)
                texts = [norm_text(all_text[n]) for n in module["slides"]]
                full_text = " ".join(texts)
                manifest = {
                    "module_id": module_id,
                    "course_id": course_id,
                    "learning_path": lp_id,
                    "module_title": module["title"],
                    "module_folder": str(module_dir.relative_to(library_root)).replace("\\", "/"),
                    "source_pptx": str(source_copy.resolve()),
                    "source_file_name": pptx.name,
                    "source_section_name": module["title"],
                    "source_slide_numbers": module["slides"],
                    "slide_count": len(module["slides"]),
                    "description": description_for(module["title"], texts),
                    "keywords": keywords_from_text(full_text),
                    "audience": "DevOps engineers, developers, release engineers, and technical stakeholders",
                    "level": "intermediate",
                    "scenario_fit": keywords_from_text(full_text)[:8],
                    "assets": assets,
                    "python_entrypoint": "module.py",
                    "assembly_notes": "Generated from inferred module divider slides because native PowerPoint Sections were not present.",
                }
                (module_dir / "module.manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
                (module_dir / "module.py").write_text(module_py(module_id, module["title"]), encoding="utf-8")
                rel_entry = {
                    **manifest,
                    "module_manifest": str((module_dir / "module.manifest.json").relative_to(library_root)).replace("\\", "/"),
                    "python_entrypoint": str((module_dir / "module.py").relative_to(library_root)).replace("\\", "/"),
                }
                course_modules.append(rel_entry)
                library_modules.append(rel_entry)

    preferred_title_slide = next(
        (candidate for candidate in title_slide_candidates if re.search(r"_(?:01|1)\.pptx$", candidate["source_file_name"], re.I)),
        title_slide_candidates[0] if title_slide_candidates else None,
    )
    course_manifest = {
        "course_id": course_id,
        "course_title": "AZ-400T00: Design and Implement Microsoft DevOps solutions" if course_id == "AZ-400" else course_id,
        "source_folder": str(source),
        "processed_at": generated_at,
        "module_count": len(course_modules),
        "source_decks": source_entries,
        "unavailable_source_decks": unavailable_source_decks,
        "title_slide_candidates": title_slide_candidates,
        "default_title_slide_style": preferred_title_slide,
        "slides_excluded": slides_excluded,
        "modules": course_modules,
    }
    (course_dir / "course.manifest.json").write_text(json.dumps(course_manifest, indent=2), encoding="utf-8")

    existing_courses = []
    existing_modules = []
    replaced_import_folders = []
    existing_manifest = library_root / "module-library.manifest.json"
    if existing_manifest.exists():
        existing = json.loads(existing_manifest.read_text(encoding="utf-8"))
        replaced_import_folders = sorted(
            {
                course.get("import_folder")
                for course in existing.get("courses", [])
                if course.get("course_id") == course_id or course.get("import_folder") == source.name
            }
        )
        existing_courses = [
            course for course in existing.get("courses", [])
            if course.get("import_folder") != source.name and course.get("course_id") != course_id
        ]
        existing_modules = [
            module for module in existing.get("modules", [])
            if module.get("import_folder") != source.name and module.get("course_id") != course_id
        ]
    for import_folder in replaced_import_folders:
        if not import_folder or import_folder == source.name:
            continue
        old_import_dir = (library_root / import_folder).resolve()
        try:
            old_import_dir.relative_to(library_root)
        except ValueError:
            continue
        if old_import_dir.exists() and old_import_dir.is_dir():
            shutil.rmtree(old_import_dir)

    for module in library_modules:
        module["import_folder"] = source.name
    imported_course = {
        "import_folder": source.name,
        "replaces_import_folders": [folder for folder in replaced_import_folders if folder and folder != source.name],
        "course_id": course_id,
        "course_title": course_manifest["course_title"],
        "course_manifest": str((course_dir / "course.manifest.json").relative_to(library_root)).replace("\\", "/"),
        "module_count": len(course_modules),
        "default_title_slide_style": preferred_title_slide,
    }
    all_courses = existing_courses + [imported_course]
    all_modules = existing_modules + library_modules
    title_slide_styles = []
    for course in all_courses:
        style = course.get("default_title_slide_style")
        if style:
            style = dict(style)
            style["course_id"] = course["course_id"]
            style["course_title"] = course["course_title"]
            style["import_folder"] = course["import_folder"]
            title_slide_styles.append(style)

    library = {
        "library_version": "0.1.0",
        "generated_at": generated_at,
        "main_library_root": str(library_root),
        "source_folder": str(source),
        "imported_source_folders": sorted({course["import_folder"] for course in all_courses}),
        "courses": all_courses,
        "modules": all_modules,
        "title_slide_styles": title_slide_styles,
        "search_metadata": [
            {
                "module_id": m["module_id"],
                "course_id": m["course_id"],
                "import_folder": m["import_folder"],
                "title": m["module_title"],
                "description": m["description"],
                "keywords": m["keywords"],
                "scenario_fit": m["scenario_fit"],
            }
            for m in all_modules
        ],
    }
    (library_root / "module-library.manifest.json").write_text(json.dumps(library, indent=2), encoding="utf-8")

    lines = [
        "# PPTX Module Library Index",
        "",
        f"Generated: {generated_at}",
        f"Main library root: `{library_root}`",
        "",
        "| Import folder | Course | Module ID | Title | Slides | Description | Keywords | Folder |",
        "|---|---|---|---|---:|---|---|---|",
    ]
    for module in all_modules:
        desc = module["description"].replace("|", "\\|")
        kws = ", ".join(module["keywords"][:8]).replace("|", "\\|")
        title = module["module_title"].replace("|", "\\|")
        lines.append(
            f"| {module['import_folder']} | {module['course_id']} | {module['module_id']} | {title} | "
            f"{module['slide_count']} | {desc} | {kws} | `{module['module_folder']}` |"
        )
    (library_root / "module-library.index.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    build(Path(args.source), Path(args.output))


if __name__ == "__main__":
    main()
