## pptx-module-library dependencies

### Included in this bundle

- `m-skills/pptx-module-library/SKILL.md`
- `m-skills/pptx-module-library/scripts/pptx_module_library_builder.py`

### Runtime outputs this skill generates (required by downstream assembler usage)

- `<main-library-root>/module-library.manifest.json`
- `<main-library-root>/module-library.index.md`
- `<main-library-root>/assemble_deck.py`
- `<main-library-root>/courses_runtime.py`
- `<main-library-root>/<import-folder>/courses/<course-id>/course.manifest.json`
- `<main-library-root>/<import-folder>/courses/<course-id>/modules/*/module.py`
- `<main-library-root>/<import-folder>/courses/<course-id>/modules/*/module.manifest.json`
- `<main-library-root>/<import-folder>/courses/<course-id>/shared/pptx_module_runtime.py`

### External runtime dependencies

- Python 3
- Windows PowerPoint COM automation (`pywin32`) for generated deck assembly runtime
- Companion Scout skill: `/pptx` (bundled in Scout)

